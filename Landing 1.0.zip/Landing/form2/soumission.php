<!DOCTYPE html>
<html lang="en">

<head>
    <title>Villa HOH </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="../img/logo-officiel-Villa-HOH.jpg" type="image/png">
    <link rel="stylesheet" href="../css/vendors/bootstrap.min.css">
    <link rel="stylesheet" href="../css/vendors/font-awesome.min.css">
    <style>
        body {

            background-size: cover;

        }

        .btn {
            margin: auto;
            display: flex;
            justify-content: space-around;
        }

        table {
            border-radius: 20px;
            width: 40%;
            height: 500px;
            margin: auto;
        }

        table .btn-danger {
            width: 100px;
            height: 20px;
        }

    </style>
</head>

<body class="text-center">



    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center">Verifiez vos informations s’il vous plait</h1>
                <table class="table table-hover table-dark">

                    <?php
                if(isset($_POST['envoyer']))
                {
                
                // message
                $message = '
                <tr>
                <td>Nom </td><td>' . $_POST['nom'] . '</td>
                </tr>
                <tr>
                <td>Prénom</td><td>' . $_POST['pnom'] . '</td>
                </tr>
                <tr>
                <td>Mail </td><td>' . $_POST['email'] . '</td>
                  <tr>
                <td>Téléphone</td><td>'. $_POST['code'] . '&nbsp'.$_POST['tel'] . '</td>
                </tr>
                </tr>
                <tr>
                <td>Lieu de résidence</td><td>'. $_POST['lieu'] . '</td>
                </tr>
                <tr>
                <td>Spécialité</td><td>' . $_POST['specialite'] . '</td>
                </tr>
                <tr>
                <td>Présentation</td><td>' . $_POST['presentation'] . '</td>
                </tr>';
               
                
                
           echo $message;
            

                }
                    ?>

                </table>
            </div>



        </div>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6 btn">

                    <form>
                        <input style="height: 50px; width :100px" class="btn btn-danger" type="button" value="Retour" onclick="history.go(-1)">
                    </form>
                    <a style="height: 50px; width :100px" class="btn btn-success" href="mailto:info@villahoh.tech?subject=FORMULAIRE&body=
Nom  :%20<?php echo  $_POST['nom']; ?>%0A%0A
Prénom :%20<?php echo  $_POST['pnom']; ?>%0A%0A
Email :%20<?php echo  $_POST['email']; ?>%0A%0A
Téléphone :%20php<?php echo $_POST['code'] ; $_POST['tel'] ?>%0A%0A
Spécialite :%20<?php echo  $_POST['specialite'] ;?>%0A%0A
Présentation :%20<?php echo  $_POST['presentation']; ?>%0A" title="Cliquez pour envoyer"> Envoyer</a>
                </div>
            </div>


        </div>

    </div>

</body>

</html>
