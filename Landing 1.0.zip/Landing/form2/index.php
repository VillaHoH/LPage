<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="FORM">
    <meta name="author" content="AKBV">
    <meta name="keywords" content="FORMULAIRE">
    <link rel="icon" href="../img/LOGO-HOH-OFFICIEL.png">

    <!-- Title Page-->
    <title>Villa HOH - Formulaire</title>

    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Enregistrez-vous pour rejoindre le mouvement</h2>
                </div>
                <div class="card-body">
                    <form method="post" action="soumission.php">
                        <div class="form-row m-b-55">
                            <div class="name">Nom</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input required class="input--style-5" type="text" name="nom">
                                            <label for="nom" class="label--desc">Nom</label>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input required class="input--style-5" type="text" name="pnom">
                                            <label for="pnom" class="label--desc">Prénom</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Email</div>
                            <div class="value">
                                <div class="input-group">
                                    <input required class="input--style-5" type="text" name="email">
                                    <label for="email" class="label--desc">email@exemple.com</label>
                                </div>

                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Lieu d'habitation</div>
                            <div class="value">
                                <div class="input-group">
                                    <input required class="input--style-5" type="text" name="lieu">
                                    <label for="lieu" class="label--desc">Pays - Ville - Commune</label>
                                </div>

                            </div>
                        </div>


                        <div class="form-row m-b-55">
                            <div class="name">Téléphone</div>
                            <div class="value">
                                <div class="row row-refine">
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input required class="input--style-5" type="text" name="code">
                                            <label for="code" class="label--desc">indicatif</label>
                                        </div>
                                    </div>
                                    <div class="col-9">
                                        <div class="input-group-desc">
                                            <input required class="input--style-5" type="text" name="tel">
                                            <label for="tel" class="label--desc">Numéro de téléphone</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Spécialité</div>
                            <div class="value">
                                <div class="input-group">
                                    <input required class="input--style-5" type="text" name="specialite">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Présentation</div>
                            <div class="value">
                                <div class="input-group">
                                    <textarea required class="input--style-5" name="presentation" id="" placeholder="Présentez-Vous"></textarea>
                                </div>
                            </div>
                        </div>

                        <div>
                            <button name="envoyer" type="submit"><span></span>
                                <span></span>
                                <span></span>
                                <span></span>Valider</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body></html>
