$(document).ready(function () {

    //NavBar
    $('i.icon').click(function () {
        $('.nav-list').slideToggle()
    });

    //Sticky NavBar
    $(window).scroll(function () {
        var sc = $(this).scrollTop();
        if (sc > 100) {
            $('header').addClass('sticky');
        } else {
            $('header').removeClass('sticky');
        }

    })
    //Carousel
    $('.carousel').carousel({
        interval: 5000
    })
})
